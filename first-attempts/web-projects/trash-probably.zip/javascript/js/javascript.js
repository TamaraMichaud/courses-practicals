//var currDate = new Date();
//this.alert(currDate);
//
//
//this.document.write("testing text here on screen");
//
//this.console.log("page loaded");
//
//var headerItem = "something",
//    footerItem = "otherthing",
//    nextItem = "banana",
//    numberThing = 26,
//    otherNumber = 893;
//
//this.window.alert(numberThing * otherNumber);
//this.document.write(headerItem + " " +
//                   footerItem + " " +
//                   nextItem);

/* Arrays */
//var myVariable = "one, two, three";
//var myArray = ["one", "two", "three"];
//
//this.window.alert(myArray[1] + " " + myVariable);
//
var elementObj = this.document.getElementById("output");
//for (var idx = 0; idx < myArray.length; idx++ ) {
//
//    elementObj.innerHTML += myArray[idx];
//    elementObj.innerHTML += "<br>";
//}


/* Multi-Dimensional Arrays */
//var mdArray = [ 
//                ["John", "Male", 31],
//                ["Lucy", "Female", 28],
//                ["Freddy", "Fluid", 16],
//                ["Brad", "Male", 54]
//              ];
//
//this.window.alert(mdArray[0][1]);


/* Functions */
function beQuiet (goddamit, mofo){

    return goddamit + " " + mofo;
}

elementObj.innerHTML = beQuiet("before i stab", "you");




