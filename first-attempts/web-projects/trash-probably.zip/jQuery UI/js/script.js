// script.js

$(function() {

   // ### DRAGGABLE ### //

   // free flow
   $('.box').draggable();

   // can be dragged over the edge of the window, window scrolls --> && if you drop it in a non-droppable element, it will return to start!
   $('#box1').draggable({scroll: true, revert: "invalid"});

   // left-right only
   $('#box2').draggable({axis: "x"});

   // trapped in a space..
   //   $('#box4').draggable({
   //      containment: ".container"}); // class/id of obj
   $('#box4').draggable({
      containment: "parent"});


   // ### DROPPABLE ### //

   $('#droppable').droppable({
      accept: '#box1',
      drop: function() { // required syntax

         $(this).find('span').html(
            "ouchie!!"); // same as "$(this).text('x')"
      }
   });

   // ### SORTABLE ### //

   $('#sortableToo').sortable();
   $('#sortable').sortable({ connectWith: "#sortableToo",
                           placeholder: "placeholderBox" // this is a css class; applies styling to the space under the object as you're dragging it arround (yellow dashed)
                           });

// ### ACCORDION ### (bootstrap is better... apparently) //

   $('#accordion').accordion({ 
      collapsible: true, // clicking again collapses the tab
      heightStyle: 'content' // by default all tabs are as big as the biggest... this makes them shrink to fit
   });
   
   // ### DATEPICKER ### displays a calendar //
   
 $('.date').datepicker({
    
    showOtherMonths: true // fills blank top-n-tail cells with other month dates
    , selectOtherMonths: true // makes those dates selectable
    , showButtonPanel: true // displays "today" and "done" buttons
    , changeMonth: true // makes the top bar of month/year into dropdowns
    , changeYear: true
    , numberOfMonths: 2 // display several monthsa t a time
    , minDate: -1 // you can only go back as far as yesterday
    // syntax:  "-1W" last week, "-1M -2W" one month and 2 weeks, "-1D" day
    // maxDate: same shiz
 });
   


});