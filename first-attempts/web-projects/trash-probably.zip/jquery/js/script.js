// jQuery script:
// long version:  $(document).ready(function() {
// but short version works fine as below:

/* *****************************************
// api.jquery.com -> what can we do with jquery!
// see "jquery selectors" on w3schools
******************************* */

// basic jquery syntax:    
//   $(selector).action();

// same as css syntax: # for id, . for class etc


// .css("property", "value") ==> OR
// .borderBottom("value") eg.  check the library for details

/* ***** Example 1 
$(function() {    

    // on page load
    $('h1').css("color","blue"); 

    // on button click
    $("button").click(function() {

        $('.thing').fadeOut(1000); // miliseconds
        $('#box').hide();

    });

});

// End of Example 1 */

/* ***** Example 2

$(function () {

    // ----------------
    // JQUERY SELECTORS
    // ----------------- 

    // select multiple elements simultaneously
    // apply/modify css using jquery
    $('h2,h3,h4').css('border', 'solid 1px red');

    //jquery-specific selectors eg
    $(':header').css('background', 'grey');
    // ^ same as 'h2,h3,h4' etc...


//    $(':contains("cos why not")').css('font-weight', 'bold');
    // ^^ this will usually select EVERYTHINg, because the element this is found in, is inside the "body" ... SO:
    $('div:contains("cos why not")').css('font-weight', 'bold');




    // select sudo-classes; the first li item
    $('li:first').css('color', 'purple');

    //even-numbered elements...!
    $('p:even').css('border', 'solid 1px blue');

    //descendant selectors; all "em"s with a div ancestor
    $('div em').css('background', 'yellow');

    //child-only selectors (i.e. no grandchildren etc)
    $('div > p').css('color', 'orange');

});

***************** end of example 2 */

/* ----------------
       JQUERY EVENT METHODS
      ----------------- */
/* ***** Example 3

$(function() {    

    $('#box').click(function () {

        alert("you just clicked the box");
    });

    //    $("input").blur(); // NOT LITERALLY "make-blurry" ! This means "when user moves away from element" / focus is no longer on this element
    $("input").blur(function() {

        if( $(this).val() == "") {

            $(this).css("border", "solid 1px red");
            $('#box').text("Forgot to add text?");
        } 

    });

    // when the user returns to the element...
    $("input").keydown(function() {

        if( $(this).val() != "") {

            $(this).css("border", "solid 1px #777");
            $('#box').text("Thanks, now click Submit");
        }
    });

    // hover in... AND HOVER OUT AGAIN!!!
    $("#box").hover(function() {

        $(this).text("Hello there...");

    }, function() {

        // ^^ this is now for hover out...
        $(this).text("Bye then...");
    });

});

***************** end of example 3 */


/* ----------------
       JQUERY CHAINING
      ----------------- */
/* ***** Example 4

$(function() {

    $(".notification-bar")
        .delay(1000)
        .slideDown()
        .delay(2000)
        .fadeOut();

});

***************** end of example 4 */

// ***** Example 5

/* ----------------
       JQUERY SHOW/HIDE
      ----------------- 

$(function () {
    $('h1').hide();
    //$('div.hidden').show();

    //$('div.hidden').fadeIn(2000);

    $('#box').click(function() {

        $(this).css("border", "solid 1px orange")
            .text("goodby cruel world...!");

        $(this).fadeTo(3000, 0.1, function() {

            $(this).css("opacity", 1)
                .text("psych") // bummer, this doesn't really work....
                .css("border", "none");

            $(this).delay(2000)
                .text("I am a box");
            // optional extra actions once animation is complete

        }); // box fade-to

        $(this).slideUp();
    }); //  box click

    $('button').click(function() {

        $('#box').slideToggle(); // alternate between slideUp and slideDown as applicable, no logic by coder required :D

    });

})


***************** end of example 5 */

/* ***** Example 6
*/
/* ----------------
       JQUERY ANIMATE
      ----------------- */
/*
$(function () {

    $('#left').click(function() {
        $('.box').animate({ // element must have "position" defined!

            // the animation effect
            left: "-=40px", // the "=" means you can repeatedly click and get this result
            fontSize: "+=2px"

        }, function() {
            //on completion of the animation, optional

        });

    }); // -- click "left"

    $('#up').click(function() {
        $('.box').animate({ // element must have "position" defined!

            // the animation effect
            top: "-=40px", // the "=" means you can repeatedly click and get this result
            opacity: "+=0.1"
        });
    }); // click up

    $('#right').click(function() {
        $('.box').animate({ // element must have "position" defined!

            // the animation effect
            left: "+=40px", // the "=" means you can repeatedly click and get this result
            fontSize: "-=2px"
        });
    }); // click right

    $('#down').click(function() {
        $('.box').animate({ // element must have "position" defined!

            // the animation effect
            top: "+=40px", // the "=" means you can repeatedly click and get this result
            opacity: "-=0.1"
        });
    }); // click down



});

***************** end of example 6 */

/* ***** Example 7
*/
/* ----------------
       JQUERY CSS
      ----------------- */

// beware users/devices with "javaScript disabled"...
// do not use jquery for the main/primary content on your site...
// jQuery should be to ENHANCE the site...

$(function () {

    $('#circle2').css('background', 'blue'); // single style only.

    //multiple styles:
    $('#circle2').css({ 'background':'blue',
                       'display': 'inline-block',
                       'height': '100px',
                       'width': '100px',
                       'margin': '20px',
                       'text-align': 'center',
                       'color': 'white',
                       'line-height': '100px'
                      })
                 .addClass("circleShape");

});

// HTML should be readable
// CSS then makes it pretty
// javaScript/JQuery is then for behaviour



/*  RACING CARS - JQUERY ANimation */

/* jQuery Animation! */
//
//$(function () {
//
//   // click the "Race!" button:
//   $('#race').click(function() {
//
//      // function to check for winner
//      function checkIfComplete(){
//
//         if(isComplete == false){
//            //no-one has won yet
//            isComplete == true;
//         } else {
//            // other car won
//            place = 'second';
//         }
//      }
//
//      // they are the same so you can pick the class... but if not you'll have a problem so...
//      var carWidth = $('#car1').width();
//      var roadLength = $('#road').width() - carWidth;
//      // ^^ we want the car to finish with nose at finish line because it's measuring from top-left
//
//      // generate a random number
//      var raceTime1 = Math.floor( (Math.random() * 5000) + 1); // between 1 and 5k (being miliseconds of race duration)
//      var raceTime2 = Math.floor( (Math.random() * 5000) + 1); // between 1 and 5k (being miliseconds of race duration)
//
//      // flag for race-ended check
//      var isComplete = false;
//      var place = 'first';
//
//      // animate! full syntax:
//      // $(element).animate(
//      //                { // actions}, time, after()
//      //                   )
//      $('#car1').animate({
//
//         left: roadLength
//
//      }, raceTime1, function() {
//
//         // check if the car has completed the race
//         checkIfComplete();
//
//         //give feedback on results
//         $('#result1 span').text('Finished in ' +
//                                 place + ' place, with a time of ' +
//                                 raceTime1 + ' ms!');
//      });
//
//      $('#car2').animate({
//
//         left: roadLength
//
//      }, raceTime2, function() {
//
//         // check if the car has completed the race
//         checkIfComplete();
//
//         //give feedback on results
//         $('#result2 span').text('Finished in ' +
//                                 place + ' place, with a time of ' +
//                                 raceTime2 + ' ms!');
//      });
//
//
//
//
//
//   });
//
//   
//   // RESET click
//   $('#reset').click(function() {
//
//      $('img').css('left','0');
//      $('#results span').text('');
//
//   });
//
//}); 




